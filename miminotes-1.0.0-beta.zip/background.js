chrome.runtime.onInstalled.addListener(()=>{console.log("MimiNotes background script loaded.")});
